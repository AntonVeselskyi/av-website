param(
    [string]$InstallDir = "$env:LOCALAPPDATA\Programs\shrt",
    [switch]$NoPath
)

$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'bin\shrt.exe'
$binDir = Join-Path $InstallDir 'bin'

New-Item -ItemType Directory -Force -Path $binDir | Out-Null
Copy-Item -LiteralPath $source -Destination (Join-Path $binDir 'shrt.exe') -Force

if (-not $NoPath) {
    $userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    $parts = @($userPath -split ';' | Where-Object { $_ })
    if ($parts -notcontains $binDir) {
        $newPath = (@($parts) + $binDir) -join ';'
        [Environment]::SetEnvironmentVariable('Path', $newPath, 'User')
    }
}

Write-Host "Installed SHRT to $binDir"
Write-Host 'Open a new terminal, then run: shrt'
