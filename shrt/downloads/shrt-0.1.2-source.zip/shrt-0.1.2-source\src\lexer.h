// lexer.h — hand-written scanner that turns .shrt source into a Token stream.
//
// The lexer is intentionally permissive: it recognizes the few constructs SHRT
// treats specially (the `$` sigil, the `??`/`??=`/`?.`/`=>` operators, the four
// flavors of string/char literal, and comments) and lumps everything else into
// Identifier / Number / single-char Punct tokens. That is enough, because the
// downstream rewriter only needs to *find* SHRT-specific tokens; all genuine
// C++ punctuation passes through untouched as a run of Punct tokens.

#pragma once

#include "token.h"
#include <string>
#include <vector>

namespace shrt
{

class Lexer
{
public:
    explicit Lexer(std::string source)
        : src_(std::move(source))
    {
    }

    // Scan the whole input. The final token is always TokenKind::End and carries
    // any trailing whitespace as its `leading`, so emitting the stream
    // reproduces a trailing newline at the end of the file.
    std::vector<Token> tokenize();

private:
    bool at_end() const
    {
        return pos_ >= src_.size();
    }

    char peek(size_t ahead = 0) const
    {
        size_t i = pos_ + ahead;
        return i < src_.size() ? src_[i] : '\0';
    }

    char advance();                     // consume one char, track line/col
    std::string scan_leading();         // consume whitespace, return it verbatim

    Token make(TokenKind kind, std::string text, std::string leading,
               int line, int col);

    Token scan_token(std::string leading);

    // Sub-scanners — each assumes the first char has NOT been consumed yet.
    Token scan_identifier(std::string leading, int line, int col);
    Token scan_number(std::string leading, int line, int col);
    Token scan_string(std::string leading, int line, int col);   // "..."
    Token scan_char(std::string leading, int line, int col);     // '...'
    Token scan_dollar(std::string leading, int line, int col);   // $ident or $"..."
    Token scan_raw_string(std::string leading, int line, int col); // R"(...)"

    std::string src_;
    size_t pos_  = 0;
    int    line_ = 1;
    int    col_  = 1;
};

} // namespace shrt
