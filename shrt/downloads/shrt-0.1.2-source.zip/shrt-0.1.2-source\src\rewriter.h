// rewriter.h — turns a SHRT token stream into C++ source text.
//
// The rewriter runs a sequence of small passes over the token vector. Each pass
// either relabels a token's `text` (keyword swaps) or performs a bounded
// structural edit (later: which→switch, => bodies, …). Because whitespace lives
// in each token's `leading` trivia, the passes never have to think about layout
// — they edit `text` and the emitter reproduces formatting for free.
//
// Pass order grows over iterations; see PROGRESS.md. Iteration 2 implements the
// keyword-swap pass only.

#pragma once

#include "token.h"
#include <string>
#include <vector>

namespace shrt
{

// A source-position-tagged problem found before transpiling.
struct Diagnostic
{
    int         line = 0;
    int         col  = 0;
    std::string message;
};

// Rule #1: user identifiers must be 2+ characters. Returns one Diagnostic per
// offending single-letter identifier. Exempt: the single-letter SHRT keywords,
// `T`/`F` (true/false), template parameters declared in a `template<…>` list,
// and member/qualified accesses (`obj.x`, `ns::x`) which may name external C++.
std::vector<Diagnostic> check_rule1(const std::vector<Token>& tokens);

class Rewriter
{
public:
    explicit Rewriter(std::vector<Token> tokens)
        : tokens_(std::move(tokens))
    {
    }

    // Run every pass in order and return the emitted C++ source. With
    // line_directives, interleaves `#line N "file"` so the compiler reports
    // errors against the original .shrt line numbers.
    std::string run(bool line_directives = false, const std::string& file = "");

    // Emit the current token stream as text (leading trivia + spelling).
    std::string emit() const;

    // Emit with `#line` directives that re-sync the compiler to the source line
    // whenever a rewrite has thrown the line count off.
    std::string emit_mapped(const std::string& file) const;

private:
    void pass_includes();       // `i x` / `li x` lines → #include (structural)
    void pass_dollar_ident();   // $vector → std::vector
    void pass_interp_string();  // $"a {e}" → std::format("a {}", e)
    void pass_print();          // p expr; → std::cout << expr << std::endl;
    void pass_which();          // which v { 1: … } → switch (v) { case 1: … }
    void pass_optional_parens();// if cond { … } → if (cond) { … }  (also w/while)
    void pass_arrow_exprbody(); // ) => expr; → ) { return expr; }
    void pass_arrow_lambda();   // => {…}/expr → [&]()\n{…}  (standalone lambdas)
    void pass_keyword_swap();
    void pass_nullsafe();       // a?.b?.c [?? fb] → IIFE with decltype temporaries
    void pass_elvis();          // ?? / ??= → guard stmt or ternary (after swap)
    void pass_defer();          // defer stmt; / defer {…} → ScopeGuard
    void pass_auto_includes();  // inject <format>/<iostream> when a feature needs it

    // Index of the nearest preceding/following token that is real code
    // (skips comments). Returns -1 / tokens_.size() past the ends.
    int  prev_code(int i) const;
    int  next_code(int i) const;

    // Transpile a captured sub-expression (interp arg, ?. fallback) so SHRT
    // operators/sigils nested inside it are handled too. Runs the expression-
    // level passes on a fresh sub-Rewriter.
    std::string transpile_fragment(const std::string& expr);

    bool at_line_start(int i) const;   // token begins a fresh source line
    bool is_stmt_pos_p(int i) const;   // is token i a print-keyword `p`?
    bool is_stmt_boundary(int p) const;// does token p (or start) end a statement?
    bool gather_lhs(int op, int& ls, int& le) const;   // postfix expr before an op
    int  gather_rhs(int start, bool stop_comma, bool stop_newline) const;
    std::string line_indent(int i) const;  // leading whitespace of token i's line
    void inject_include(const std::string& directive);  // after the last #include
    void inject_runtime();      // the shrt_runtime::ScopeGuard helper (for defer)

    std::vector<Token> tokens_;
    bool needs_format_   = false;
    bool needs_iostream_ = false;
    int  chain_counter_  = 0;   // unique temp names for ?. IIFEs
};

} // namespace shrt
