#pragma once

#include <iosfwd>
#include <string>

namespace shrt::mascot
{

// Print the resting mascot used by the help screen.
void print(std::ostream& out);

// Play the original fox-like pine marten animation when stderr is an
// interactive terminal. Redirected/editor invocations remain silent.
void play(const std::string& file);

} // namespace shrt::mascot
