#include "mascot.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <thread>

#ifdef _WIN32
#include <io.h>
#include <windows.h>
#else
#include <unistd.h>
#endif

namespace shrt::mascot
{
namespace
{

constexpr const char* reset      = "\033[0m";
constexpr const char* bold       = "\033[1m";
constexpr const char* coral      = "\033[38;2;255;111;97m";
constexpr const char* aqua_green = "\033[38;2;64;224;208m";
constexpr const char* sun_yellow = "\033[38;2;255;211;67m";
constexpr const char* sky_blue   = "\033[38;2;71;145;255m";

using Frame = std::array<const char*, 3>;
constexpr int block_height = 5;

constexpr std::array<Frame, 13> frames = {{
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--\(  o . o  )/----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--\( 'O . O' )/----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--\( 'O . O' )/----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--\( 'O . o  )|----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--|( 'O . o  )/----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--\(  o . O' )|----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--|(  o . O' )/----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--/(  o . o  )\----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--|(  - . -  )|----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--|(  ^ . ^  )|----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--\(  ^ . ^  )/----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--|(  o . o  )|----)"}},
    {{R"(     /\   /\       )", R"(    /  \_/  \      )", R"(--\(  o . o  )/----)"}}
}};

bool no_color()
{
    return std::getenv("NO_COLOR") != nullptr;
}

bool animation_disabled()
{
    const char* value = std::getenv("SHRT_NO_ANIMATION");
    return value != nullptr && std::string(value) != "0";
}

bool stderr_is_terminal()
{
#ifdef _WIN32
    if (_isatty(_fileno(stderr)) == 0)
    {
        return false;
    }
    HANDLE handle = GetStdHandle(STD_ERROR_HANDLE);
    DWORD mode = 0;
    if (handle != INVALID_HANDLE_VALUE && GetConsoleMode(handle, &mode))
    {
        SetConsoleMode(handle, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
    }
    return true;
#else
    return isatty(STDERR_FILENO) != 0;
#endif
}

std::string progress_bar(double progress, bool color)
{
    constexpr int width = 28;
    progress = std::clamp(progress, 0.0, 1.0);
    const int filled = static_cast<int>(progress * width + 0.5);
    const int percent = static_cast<int>(progress * 100.0 + 0.5);
    std::ostringstream out;
    if (color) out << coral;
    out << '[';
    for (int index = 0; index < width; ++index)
    {
        if (color) out << (index < filled ? sun_yellow : sky_blue);
        out << (index < filled ? "█" : "░");
    }
    if (color) out << coral;
    out << "] ";
    if (color) out << bold << sun_yellow;
    out << std::setw(3) << percent << '%';
    if (color) out << reset;
    return out.str();
}

void clear_line()
{
    std::cerr << "\r\033[2K";
}

void draw(const Frame& frame, const std::string& file, double progress, bool color)
{
    std::cerr << "\033[" << block_height << 'A';
    for (const char* line : frame)
    {
        clear_line();
        if (color) std::cerr << coral;
        std::cerr << line;
        if (color) std::cerr << reset;
        std::cerr << '\n';
    }
    clear_line();
    if (color) std::cerr << sky_blue;
    std::cerr << "Transpiling: ";
    if (color) std::cerr << aqua_green;
    std::cerr << file;
    if (color) std::cerr << reset;
    std::cerr << '\n';
    clear_line();
    std::cerr << progress_bar(progress, color) << '\n' << std::flush;
}

void clear_block()
{
    std::cerr << "\033[" << block_height << 'A';
    for (int line = 0; line < block_height; ++line)
    {
        clear_line();
        std::cerr << '\n';
    }
    std::cerr << "\033[" << block_height << 'A' << std::flush;
}

} // namespace

void print(std::ostream& out)
{
    out << frames[9][0] << '\n'
        << frames[9][1] << '\n'
        << frames[9][2] << '\n';
}

void play(const std::string& file)
{
    if (animation_disabled() || !stderr_is_terminal())
    {
        return;
    }
    const bool color = !no_color();
    for (int line = 0; line < block_height; ++line)
    {
        std::cerr << '\n';
    }
    for (std::size_t index = 0; index < frames.size(); ++index)
    {
        draw(frames[index], file, static_cast<double>(index + 1) / frames.size(), color);
        std::this_thread::sleep_for(std::chrono::milliseconds(index == 8 ? 70 : 28));
    }
    clear_block();
}

} // namespace shrt::mascot
