// token.h — token kinds and the Token value type for the SHRT lexer.
//
// The lexer produces a flat stream of Tokens. Whitespace (including newlines)
// is NOT a token; it is attached to the following token as `leading` trivia so
// the emitter can reproduce the user's exact layout. Comments ARE tokens so the
// rewriter can see and pass them through deliberately.
//
// Design note: every Token stores its exact source `text`. The transpiler is
// "syntax sugar" — we keep the user's formatting and only swap the lexemes that
// differ between SHRT and C++. Re-emitting `leading + text` for every token
// reproduces the source byte-for-byte when no rewrite applies.

#pragma once

#include <string>
#include <string_view>

namespace shrt
{

enum class TokenKind
{
    End,            // end of input

    Identifier,     // foo, bar, class_count — also where SHRT keywords live
    Number,         // 42, 3.14, 0xFF, 1'000, 5u
    StringLit,      // "..."
    CharLit,        // '...'
    RawString,      // R"(...)"
    InterpString,   // $"...{expr}..."
    DollarIdent,    // $vector, $cout  (text keeps the leading '$')

    LineComment,    // // ...
    BlockComment,   // /* ... */

    // SHRT-significant multi-char operators (the rewriter transforms these)
    Elvis,          // ??
    ElvisAssign,    // ??=
    NullSafe,       // ?.
    Arrow2,         // =>

    Punct,          // any other single punctuation char: ( ) { } ; , : ? . etc.
};

struct Token
{
    TokenKind   kind = TokenKind::End;
    std::string text;        // exact source spelling of the token
    std::string leading;     // whitespace + newlines immediately before it
    int         line = 0;    // 1-based source line (0 = synthesized, no position)
    int         col  = 0;    // 1-based source column (0 = synthesized)

    bool is(TokenKind k) const
    {
        return kind == k;
    }

    // Convenience: does an Identifier token spell exactly `word`?
    bool is_word(std::string_view word) const
    {
        return kind == TokenKind::Identifier && text == word;
    }
};

// Human-readable name for a kind — used by the token-dump debug mode.
const char* kind_name(TokenKind kind);

} // namespace shrt
