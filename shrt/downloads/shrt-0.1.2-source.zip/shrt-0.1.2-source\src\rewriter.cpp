// rewriter.cpp — see rewriter.h. Iteration 2: keyword-swap pass.

#include "rewriter.h"
#include "lexer.h"
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <cstddef>
#include <cctype>

namespace shrt
{

static std::string trim(const std::string& s)
{
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos)
    {
        return "";
    }
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

// The 1:1 keyword table from spec.md (plus `nil`→nullptr, which the playground
// converter supports and the example programs use). Multi-token features —
// includes (`i`/`li`), `which`, optional parens, `=>`, `??` — are handled by
// later passes, not here.
//
// `e` is special: normally `enum class`, but `using e` must become `using enum`
// (C++20's `using enum` takes a plain enum-type name). Handled inline below.
static const std::unordered_map<std::string, std::string>& keyword_table()
{
    static const std::unordered_map<std::string, std::string> table = {
        {"c", "class"},      {"s", "struct"},     {"a", "auto"},
        {"f", "for"},        {"w", "while"},      {"el", "else"},
        {"v", "virtual"},    {"n", "namespace"},  {"u", "using"},
        {"k", "const"},      {"d", "delete"},     {"o", "override"},
        {"r", "return"},     {"b", "break"},      {"cont", "continue"},
        {"ke", "constexpr"}, {"op", "operator"},  {"pub", "public"},
        {"pri", "private"},  {"pro", "protected"},{"nil", "nullptr"},
        // `e` deliberately omitted here — handled with its using-enum special case.
    };
    return table;
}

std::vector<Diagnostic> check_rule1(const std::vector<Token>& toks)
{
    // Single-letter SHRT keywords (incl. `i` include, `p` print) plus the
    // exempt `T`/`F`. These are language tokens, never user names.
    static const std::unordered_set<std::string> reserved = {
        "a", "b", "c", "d", "e", "f", "i", "k", "n", "o",
        "p", "r", "s", "u", "v", "w", "T", "F"
    };

    int n = static_cast<int>(toks.size());

    // Gather single-letter names declared inside any `template< … >` list; they
    // are exempt everywhere they are later used.
    std::unordered_set<std::string> tparams;
    for (int i = 0; i < n; ++i)
    {
        if (!(toks[i].kind == TokenKind::Identifier && toks[i].text == "template"))
        {
            continue;
        }
        int j = i + 1;
        while (j < n && !(toks[j].kind == TokenKind::Punct && toks[j].text == "<") &&
               !(toks[j].kind == TokenKind::Punct && toks[j].text == ";"))
        {
            ++j;
        }
        if (j >= n || toks[j].text != "<")
        {
            continue;
        }
        int depth = 0;
        for (int k = j; k < n; ++k)
        {
            if (toks[k].kind == TokenKind::Punct && toks[k].text == "<") { ++depth; }
            else if (toks[k].kind == TokenKind::Punct && toks[k].text == ">")
            {
                --depth;
                if (depth == 0) { break; }
            }
            else if (toks[k].kind == TokenKind::Identifier && toks[k].text.size() == 1)
            {
                tparams.insert(toks[k].text);
            }
        }
    }

    std::vector<Diagnostic> diags;
    for (int i = 0; i < n; ++i)
    {
        const Token& t = toks[i];
        if (t.kind != TokenKind::Identifier || t.text.size() != 1)
        {
            continue;
        }
        if (!std::isalpha(static_cast<unsigned char>(t.text[0])))
        {
            continue;
        }
        if (reserved.count(t.text) || tparams.count(t.text))
        {
            continue;
        }
        // Skip member/qualified accesses — may name external (non-SHRT) C++.
        int p = i - 1;
        while (p >= 0 &&
               (toks[p].kind == TokenKind::LineComment || toks[p].kind == TokenKind::BlockComment))
        {
            --p;
        }
        if (p >= 0 && (toks[p].kind == TokenKind::NullSafe ||
                       (toks[p].kind == TokenKind::Punct &&
                        (toks[p].text == "." || toks[p].text == "->" || toks[p].text == "::"))))
        {
            continue;
        }
        diags.push_back({t.line, t.col,
            "single-letter identifier '" + t.text +
            "' is reserved; user names must be 2+ characters (rule #1)"});
    }
    return diags;
}

int Rewriter::prev_code(int i) const
{
    for (int j = i - 1; j >= 0; --j)
    {
        TokenKind k = tokens_[j].kind;
        if (k != TokenKind::LineComment && k != TokenKind::BlockComment)
        {
            return j;
        }
    }
    return -1;
}

int Rewriter::next_code(int i) const
{
    for (int j = i + 1; j < static_cast<int>(tokens_.size()); ++j)
    {
        TokenKind k = tokens_[j].kind;
        if (k != TokenKind::LineComment && k != TokenKind::BlockComment)
        {
            return j;
        }
    }
    return static_cast<int>(tokens_.size());
}

void Rewriter::pass_keyword_swap()
{
    const auto& table = keyword_table();

    for (int i = 0; i < static_cast<int>(tokens_.size()); ++i)
    {
        Token& tok = tokens_[i];
        if (tok.kind != TokenKind::Identifier)
        {
            continue;
        }

        // Guard 1 — member access: `obj.r`, `ptr->r`, `obj?.r`. The letter is a
        // member name, not a keyword. (Rule #1 forbids single-letter *user*
        // names, but C++ interop types may have short members, so guard anyway.)
        int p = prev_code(i);
        if (p >= 0)
        {
            const Token& pt = tokens_[p];
            if (pt.kind == TokenKind::NullSafe ||
                (pt.kind == TokenKind::Punct &&
                 (pt.text == "." || pt.text == "->" || pt.text == "::")))
            {
                continue;
            }
        }

        // Guard 2 — qualifier: `r::x` uses the letter as a namespace/type name.
        int nx = next_code(i);
        if (nx < static_cast<int>(tokens_.size()) &&
            tokens_[nx].kind == TokenKind::Punct && tokens_[nx].text == "::")
        {
            continue;
        }

        // Special case: `e` → `enum class`, except after `using` → `enum`.
        if (tok.text == "e")
        {
            bool using_enum = false;
            if (p >= 0 && tokens_[p].kind == TokenKind::Identifier)
            {
                const std::string& pw = tokens_[p].text;
                using_enum = (pw == "using" || pw == "u");
            }
            tok.text = using_enum ? "enum" : "enum class";
            continue;
        }

        auto it = table.find(tok.text);
        if (it != table.end())
        {
            tok.text = it->second;
        }
    }
}

bool Rewriter::at_line_start(int i) const
{
    if (i == 0)
    {
        return true;
    }
    return tokens_[i].leading.find('\n') != std::string::npos;
}

// `i <name>` → #include <name>,  `li <name>` → #include "name".
// Line-oriented: the target is every code token on the same line after the
// keyword (comments end the target and are preserved). Runs first so include
// targets are never mistaken for keywords by the swap pass.
void Rewriter::pass_includes()
{
    std::vector<Token> out;
    out.reserve(tokens_.size());

    int i = 0;
    while (i < static_cast<int>(tokens_.size()))
    {
        const Token& tok = tokens_[i];
        bool is_inc = tok.kind == TokenKind::Identifier &&
                      (tok.text == "i" || tok.text == "li") &&
                      at_line_start(i);
        if (!is_inc)
        {
            out.push_back(tok);
            ++i;
            continue;
        }

        bool local = tok.text == "li";
        int  j     = i + 1;
        std::string target;
        while (j < static_cast<int>(tokens_.size()))
        {
            const Token& t = tokens_[j];
            if (t.kind == TokenKind::End ||
                t.kind == TokenKind::LineComment ||
                t.kind == TokenKind::BlockComment ||
                t.leading.find('\n') != std::string::npos)
            {
                break;
            }
            target += t.text;
            ++j;
        }
        target = trim(target);
        if (target.empty())
        {
            out.push_back(tok);     // lone `i`/`li` — leave it alone
            ++i;
            continue;
        }
        if (target.front() == '"') { target.erase(0, 1); }
        if (!target.empty() && target.back() == '"') { target.pop_back(); }

        Token inc      = tok;       // inherit leading/line/col
        inc.text       = local ? ("#include \"" + target + "\"")
                               : ("#include <" + target + ">");
        out.push_back(inc);
        i = j;                      // skip the consumed target tokens
    }
    tokens_ = std::move(out);
}

// $vector → std::vector  (the sigil already guarantees this is std::, never a
// keyword, so it is immune to the swap pass).
void Rewriter::pass_dollar_ident()
{
    for (Token& tok : tokens_)
    {
        if (tok.kind == TokenKind::DollarIdent)
        {
            tok.text = "std::" + tok.text.substr(1);
        }
    }
}

// Re-transpile a captured sub-expression so SHRT constructs nested inside it
// (`$ident`, `$"…"`, `?.`, `??`) are handled. Fast-path returns the text
// unchanged when it holds no sigil/operator characters at all.
std::string Rewriter::transpile_fragment(const std::string& expr)
{
    if (expr.find_first_of("$?") == std::string::npos)
    {
        return expr;
    }
    Lexer lex(expr);
    Rewriter sub(lex.tokenize());
    sub.pass_dollar_ident();
    sub.pass_interp_string();
    sub.pass_keyword_swap();
    sub.pass_nullsafe();
    sub.pass_elvis();
    return sub.emit();
}

// $"text {expr} more" → std::format("text {} more", expr).
// With no {…} placeholders it collapses to a plain "text" literal (no format,
// no header needed) — matching the playground converter. Each {expr} is itself
// re-transpiled so nested SHRT operators/sigils are handled.
void Rewriter::pass_interp_string()
{
    for (Token& tok : tokens_)
    {
        if (tok.kind != TokenKind::InterpString)
        {
            continue;
        }
        // strip the leading $" and trailing "
        std::string inner = tok.text.substr(2, tok.text.size() - 3);

        std::string fmt;
        std::vector<std::string> args;
        for (size_t k = 0; k < inner.size();)
        {
            char c = inner[k];
            if (c == '{')
            {
                size_t close = inner.find('}', k);
                if (close == std::string::npos)
                {
                    fmt.push_back(c);   // unmatched brace — keep literal
                    ++k;
                    continue;
                }
                args.push_back(trim(inner.substr(k + 1, close - (k + 1))));
                fmt += "{}";
                k = close + 1;
            }
            else
            {
                fmt.push_back(c);
                ++k;
            }
        }

        if (args.empty())
        {
            tok.text = "\"" + fmt + "\"";
        }
        else
        {
            std::string call = "std::format(\"" + fmt + "\"";
            for (const std::string& a : args)
            {
                call += ", " + transpile_fragment(a);
            }
            call += ")";
            tok.text      = call;
            needs_format_ = true;
        }
    }
}

// Is token i a print-keyword `p` (vs a member `obj.p`)? Rule #1 reserves
// single letters, so `p` is the print keyword whenever it sits at a statement
// boundary and is not a member/qualified name.
bool Rewriter::is_stmt_pos_p(int i) const
{
    const Token& t = tokens_[i];
    if (t.kind != TokenKind::Identifier || t.text != "p")
    {
        return false;
    }

    int p = prev_code(i);
    if (p >= 0)
    {
        const Token& pt = tokens_[p];
        if (pt.kind == TokenKind::NullSafe ||
            (pt.kind == TokenKind::Punct &&
             (pt.text == "." || pt.text == "->" || pt.text == "::")))
        {
            return false;   // member access
        }
        // A statement starts after these, or at the start of a line.
        bool boundary =
            (pt.kind == TokenKind::Punct &&
             (pt.text == ";" || pt.text == "{" || pt.text == "}" ||
              pt.text == ":" || pt.text == ")")) ||
            (pt.kind == TokenKind::Identifier &&
             (pt.text == "else" || pt.text == "do" || pt.text == "defer"));
        if (!boundary && !at_line_start(i))
        {
            return false;
        }
    }
    return true;
}

// p <expr>;  →  std::cout << <expr> << std::endl;
// Also the block-final form `p <expr>` immediately before a `}` (no semicolon),
// which gains a semicolon. The expression is single-line and brace/semicolon
// free, mirroring the playground's `[^;{}\n]+` capture.
void Rewriter::pass_print()
{
    std::vector<Token> out;
    out.reserve(tokens_.size());

    int i = 0;
    while (i < static_cast<int>(tokens_.size()))
    {
        if (!is_stmt_pos_p(i))
        {
            out.push_back(tokens_[i]);
            ++i;
            continue;
        }

        // Scan the expression up to its terminator.
        int  j     = i + 1;
        bool semi  = false;
        bool brace = false;
        while (j < static_cast<int>(tokens_.size()))
        {
            const Token& t = tokens_[j];
            // Terminators are checked first so the block-final form (a `}` that
            // closes the enclosing block on the *next* line) is still detected.
            if (t.kind == TokenKind::Punct && t.text == ";") { semi  = true; break; }
            if (t.kind == TokenKind::Punct && t.text == "}") { brace = true; break; }
            if (t.kind == TokenKind::Punct && t.text == "{") { break; }
            if (t.kind == TokenKind::End)                    { break; }
            if (j > i + 1 && t.leading.find('\n') != std::string::npos)
            {
                break;      // expression ran to a new line without a terminator
            }
            ++j;
        }

        bool has_expr = j > i + 1;
        if (!(has_expr && (semi || brace)))
        {
            out.push_back(tokens_[i]);   // not a well-formed print — leave `p`
            ++i;
            continue;
        }

        // Parenthesize a multi-token expression so a low-precedence operator
        // (ternary, `||`, comma, …) can't bind across the `<<` — `p a ? b : c;`
        // must be `std::cout << (a ? b : c) << std::endl`, not `(std::cout << a) ? …`.
        // A single-token expression (bare name/literal/`$"…"` node) needs no parens.
        bool wrap = (j - (i + 1)) > 1;
        Token head    = tokens_[i];
        head.text     = wrap ? "std::cout << (" : "std::cout <<";
        out.push_back(head);
        for (int k = i + 1; k < j; ++k)
        {
            Token t = tokens_[k];
            if (k == i + 1)
            {
                t.leading = wrap ? "" : " ";
            }
            out.push_back(t);
        }
        Token tail;
        tail.kind    = TokenKind::Identifier;
        tail.leading = "";
        tail.text    = wrap ? (brace ? ") << std::endl;" : ") << std::endl")
                            : (brace ? " << std::endl;" : " << std::endl");
        out.push_back(tail);

        needs_iostream_ = true;
        if (semi)
        {
            out.push_back(tokens_[j]);   // keep the ';'
            i = j + 1;
        }
        else
        {
            i = j;                       // leave the '}' for the next iteration
        }
    }
    tokens_ = std::move(out);
}

// Try to read a case/default label beginning at token k (which is at a line
// start, brace-depth 1 inside a switch body). On success, appends the rewritten
// label tokens to `out` and returns the index just past the label's `:`. On no
// match returns -1 and appends nothing.
//
// A label is:   default :              → left as `default:`
//          or   <expr> :               → `case <expr>:`
// where <expr> is a simple constant: an optional +/-, then a Number/CharLit, or
// an Identifier with an optional `::Identifier` qualifier chain. The trailing
// `:` must be a single colon (the lexer keeps `::` as one token, so a qualifier
// never reaches the colon test). Statements like `obj->f();` or `a ? b : c;`
// fail the simple-token shape and are left untouched.
static int try_case_label(const std::vector<Token>& toks, int k, std::vector<Token>& out)
{
    auto is_punct = [&](int idx, const char* s)
    {
        return idx < static_cast<int>(toks.size()) &&
               toks[idx].kind == TokenKind::Punct && toks[idx].text == s;
    };

    // `default:`
    if (toks[k].kind == TokenKind::Identifier && toks[k].text == "default" &&
        is_punct(k + 1, ":"))
    {
        out.push_back(toks[k]);
        out.push_back(toks[k + 1]);
        return k + 2;
    }

    int p = k;
    if (is_punct(p, "-") || is_punct(p, "+"))
    {
        ++p;
    }
    if (p < static_cast<int>(toks.size()) &&
        (toks[p].kind == TokenKind::Number || toks[p].kind == TokenKind::CharLit))
    {
        ++p;
    }
    else if (p < static_cast<int>(toks.size()) &&
             toks[p].kind == TokenKind::Identifier && toks[p].text != "default")
    {
        ++p;
        while (is_punct(p, "::") && p + 1 < static_cast<int>(toks.size()) &&
               toks[p + 1].kind == TokenKind::Identifier)
        {
            p += 2;
        }
    }
    else
    {
        return -1;
    }

    if (!is_punct(p, ":"))
    {
        return -1;
    }

    Token cs;
    cs.kind    = TokenKind::Identifier;
    cs.text    = "case";
    cs.leading = toks[k].leading;
    out.push_back(cs);
    for (int idx = k; idx < p; ++idx)
    {
        Token t = toks[idx];
        if (idx == k)
        {
            t.leading = " ";
        }
        out.push_back(t);
    }
    out.push_back(toks[p]);     // the ':'
    return p + 1;
}

// which <value> { <labels…> }  →  switch (<value>) { case <labels…> }.
// One left-to-right sweep transforms every top-level `which`, copying any nested
// `which` verbatim; the outer loop repeats so nested ones are picked up next
// sweep (after their enclosing block became `switch`).
void Rewriter::pass_which()
{
    for (int guard = 0; guard < 64; ++guard)
    {
        bool found = false;
        std::vector<Token> out;
        out.reserve(tokens_.size() + 8);

        int i = 0;
        int n = static_cast<int>(tokens_.size());
        while (i < n)
        {
            const Token& tok = tokens_[i];
            bool is_which = tok.kind == TokenKind::Identifier && tok.text == "which";
            if (is_which)
            {
                int p = prev_code(i);
                if (p >= 0 && (tokens_[p].kind == TokenKind::NullSafe ||
                               (tokens_[p].kind == TokenKind::Punct &&
                                (tokens_[p].text == "." || tokens_[p].text == "->" ||
                                 tokens_[p].text == "::"))))
                {
                    is_which = false;   // member/qualified — not the keyword
                }
            }
            if (!is_which)
            {
                out.push_back(tok);
                ++i;
                continue;
            }

            // Gather the value tokens between `which` and the opening `{`.
            int j = i + 1;
            std::vector<int> val;
            while (j < n && !(tokens_[j].kind == TokenKind::Punct && tokens_[j].text == "{") &&
                   tokens_[j].kind != TokenKind::End)
            {
                val.push_back(j);
                ++j;
            }
            if (j >= n || !(tokens_[j].kind == TokenKind::Punct && tokens_[j].text == "{"))
            {
                out.push_back(tok);     // malformed which — leave it
                ++i;
                continue;
            }

            found = true;

            Token sw   = tok;
            sw.text    = "switch";
            out.push_back(sw);

            bool already_paren = !val.empty() &&
                tokens_[val.front()].kind == TokenKind::Punct && tokens_[val.front()].text == "(" &&
                tokens_[val.back()].kind  == TokenKind::Punct && tokens_[val.back()].text  == ")";

            if (already_paren)
            {
                for (int v : val)
                {
                    out.push_back(tokens_[v]);
                }
            }
            else
            {
                Token lp;
                lp.kind    = TokenKind::Punct;
                lp.text    = "(";
                lp.leading = val.empty() ? " " : tokens_[val.front()].leading;
                out.push_back(lp);
                for (size_t vi = 0; vi < val.size(); ++vi)
                {
                    Token t = tokens_[val[vi]];
                    if (vi == 0)
                    {
                        t.leading = "";
                    }
                    out.push_back(t);
                }
                Token rp;
                rp.kind    = TokenKind::Punct;
                rp.text    = ")";
                rp.leading = "";
                out.push_back(rp);
            }

            out.push_back(tokens_[j]);          // opening '{'

            // Walk the brace-balanced body; relabel labels at depth 1.
            int k     = j + 1;
            int depth = 1;
            while (k < n && depth > 0)
            {
                const Token& t = tokens_[k];
                if (t.kind == TokenKind::Punct && t.text == "{")
                {
                    ++depth;
                    out.push_back(t);
                    ++k;
                    continue;
                }
                if (t.kind == TokenKind::Punct && t.text == "}")
                {
                    --depth;
                    out.push_back(t);
                    ++k;
                    continue;
                }
                if (depth == 1 && t.leading.find('\n') != std::string::npos)
                {
                    int after = try_case_label(tokens_, k, out);
                    if (after >= 0)
                    {
                        k = after;
                        continue;
                    }
                }
                out.push_back(t);
                ++k;
            }
            i = k;
        }

        tokens_ = std::move(out);
        if (!found)
        {
            break;
        }
    }
}

// if cond { … }  →  if (cond) { … }   (and `w`/`while` the same).
// Block form only: the condition is every token between the keyword and the
// opening `{`. If the condition is already parenthesized (first token is `(`,
// matching the playground's `(?!\()`) it is left alone. `for` is untouched —
// SHRT for-loops keep their parens (`f (…)`). Single-line brace-less bodies are
// not handled (the Allman style mandate means bodies are always braced).
void Rewriter::pass_optional_parens()
{
    std::vector<Token> out;
    out.reserve(tokens_.size() + 8);

    int i = 0;
    int n = static_cast<int>(tokens_.size());
    while (i < n)
    {
        const Token& tok = tokens_[i];
        bool is_cond_kw = tok.kind == TokenKind::Identifier &&
                          (tok.text == "if" || tok.text == "w" || tok.text == "while");
        if (is_cond_kw)
        {
            int p = prev_code(i);
            if (p >= 0 && (tokens_[p].kind == TokenKind::NullSafe ||
                           (tokens_[p].kind == TokenKind::Punct &&
                            (tokens_[p].text == "." || tokens_[p].text == "->" ||
                             tokens_[p].text == "::"))))
            {
                is_cond_kw = false;     // member/qualified — not the keyword
            }
        }
        if (!is_cond_kw)
        {
            out.push_back(tok);
            ++i;
            continue;
        }

        // Gather condition tokens up to the opening '{' (same statement: bail on
        // ';', a new line, or end — those mean it is not a brace-form condition).
        int j = i + 1;
        bool ok = false;
        while (j < n)
        {
            const Token& t = tokens_[j];
            if (t.kind == TokenKind::Punct && t.text == "{") { ok = true; break; }
            if (t.kind == TokenKind::End) { break; }
            if (t.kind == TokenKind::Punct && t.text == ";") { break; }
            if (j > i + 1 && t.leading.find('\n') != std::string::npos) { break; }
            ++j;
        }

        bool has_cond = j > i + 1;
        bool already_paren = has_cond &&
            tokens_[i + 1].kind == TokenKind::Punct && tokens_[i + 1].text == "(";

        if (!ok || !has_cond || already_paren)
        {
            out.push_back(tok);         // leave the keyword; no paren rewrite
            ++i;
            continue;
        }

        out.push_back(tok);             // keyword (w→while happens in the swap pass)
        Token lp;
        lp.kind    = TokenKind::Punct;
        lp.text    = "(";
        lp.leading = tokens_[i + 1].leading;    // inherit the space after the kw
        out.push_back(lp);
        for (int k = i + 1; k < j; ++k)
        {
            Token t = tokens_[k];
            if (k == i + 1)
            {
                t.leading = "";
            }
            out.push_back(t);
        }
        Token rp;
        rp.kind    = TokenKind::Punct;
        rp.text    = ")";
        rp.leading = "";
        out.push_back(rp);
        i = j;                          // continue at the '{'
    }
    tokens_ = std::move(out);
}

// Indentation (leading whitespace after the last newline) of the line that
// token i sits on. Scans back to the first token whose leading carries a '\n'.
std::string Rewriter::line_indent(int i) const
{
    for (int j = i; j >= 0; --j)
    {
        size_t nl = tokens_[j].leading.rfind('\n');
        if (nl != std::string::npos)
        {
            return tokens_[j].leading.substr(nl + 1);
        }
    }
    return "";
}

static bool is_trailing_qualifier(const Token& t)
{
    if (t.kind != TokenKind::Identifier)
    {
        return false;
    }
    // This pass runs before the keyword swap, so the SHRT shortcuts `k` (const)
    // and `o` (override) must be recognized alongside their spelled-out forms.
    return t.text == "k" || t.text == "o" ||
           t.text == "const" || t.text == "override" ||
           t.text == "noexcept" || t.text == "final" || t.text == "mutable";
}

// Index of the `(` matching the `)` at jp, or -1.
static int match_open_paren(const std::vector<Token>& toks, int jp)
{
    int depth = 0;
    for (int j = jp; j >= 0; --j)
    {
        if (toks[j].kind == TokenKind::Punct && toks[j].text == ")") { ++depth; }
        else if (toks[j].kind == TokenKind::Punct && toks[j].text == "(")
        {
            --depth;
            if (depth == 0) { return j; }
        }
    }
    return -1;
}

// Expression-body `=>`:  <sig>) [quals] => <expr>;  →
//     <sig>) [quals]
//     {
//         return <expr>;
//     }
// The `=>` must sit just after a `)` (skipping trailing qualifiers like `k`).
// If a `[capture]` precedes the matching `(` it is a lambda expression body, so
// the closing brace keeps the assignment's `;` (`};`); otherwise it is a free
// function/method definition and the `;` is dropped. Standalone lambdas
// (`=> {…}`, `=> expr`, `[cap] => …`) are a separate, later pass.
void Rewriter::pass_arrow_exprbody()
{
    std::vector<Token> out;
    out.reserve(tokens_.size() + 16);

    int i = 0;
    int n = static_cast<int>(tokens_.size());
    while (i < n)
    {
        if (tokens_[i].kind != TokenKind::Arrow2)
        {
            out.push_back(tokens_[i]);
            ++i;
            continue;
        }

        // Walk back past qualifiers to find a closing ')'.
        int j = prev_code(i);
        while (j >= 0 && is_trailing_qualifier(tokens_[j]))
        {
            j = prev_code(j);
        }
        bool after_paren = j >= 0 && tokens_[j].kind == TokenKind::Punct &&
                           tokens_[j].text == ")";
        if (!after_paren)
        {
            out.push_back(tokens_[i]);   // not an expression body — leave `=>`
            ++i;
            continue;
        }

        // Gather the expression up to its terminating ';' (no '{' allowed).
        int  s     = i + 1;
        bool found = false;
        while (s < n)
        {
            const Token& t = tokens_[s];
            if (t.kind == TokenKind::Punct && t.text == ";") { found = true; break; }
            if (t.kind == TokenKind::Punct && t.text == "{") { break; }
            if (t.kind == TokenKind::End) { break; }
            ++s;
        }
        if (!found || s == i + 1)
        {
            out.push_back(tokens_[i]);
            ++i;
            continue;
        }

        int  op        = match_open_paren(tokens_, j);
        bool is_lambda = op > 0 && prev_code(op) >= 0 &&
                         tokens_[prev_code(op)].kind == TokenKind::Punct &&
                         tokens_[prev_code(op)].text == "]";
        // Distinguish a lambda capture `[…](…)` from `operator[](…)`: in the
        // latter the brackets are empty and preceded by `op`/`operator`, so it is
        // a function definition, not a lambda (no trailing `;`).
        if (is_lambda)
        {
            int rb = prev_code(op);              // the ']'
            int lb = prev_code(rb);              // a '[' iff the brackets are empty
            if (lb >= 0 && tokens_[lb].kind == TokenKind::Punct && tokens_[lb].text == "[")
            {
                int before = prev_code(lb);
                if (before >= 0 && tokens_[before].kind == TokenKind::Identifier &&
                    (tokens_[before].text == "op" || tokens_[before].text == "operator"))
                {
                    is_lambda = false;
                }
            }
        }
        std::string indent = line_indent(i);

        Token ob;
        ob.kind = TokenKind::Punct;
        ob.text = "{";
        ob.leading = "\n" + indent;
        out.push_back(ob);

        Token ret;
        ret.kind = TokenKind::Identifier;
        ret.text = "return";
        ret.leading = "\n" + indent + "    ";
        out.push_back(ret);

        for (int k = i + 1; k < s; ++k)
        {
            Token t = tokens_[k];
            if (k == i + 1)
            {
                t.leading = " ";
            }
            out.push_back(t);
        }

        Token semi = tokens_[s];
        semi.leading = "";
        out.push_back(semi);                 // the return statement's ';'

        Token cb;
        cb.kind = TokenKind::Punct;
        cb.text = is_lambda ? "};" : "}";    // lambda keeps the assignment ';'
        cb.leading = "\n" + indent;
        out.push_back(cb);

        i = s + 1;
    }
    tokens_ = std::move(out);
}

// Standalone lambdas — every `=>` left after the expression-body pass. SHRT
// lambdas take no parameters and default to `[&]` capture; an explicit `[cap]`
// written just before the `=>` is kept. Three body shapes:
//   => { … }      → [&]()\n{ … }                 (block; brace moves to its own line)
//   => p "x"      → [&]()\n{ std::cout << "x" << std::endl; }
//   => expr       → [&]()\n{ return expr; }       (expr ends at ; { } , ) or newline)
// Terminators (`;`/`)`/`,`/`}`) are left in the stream, so an assignment's `;`
// naturally becomes `};` and a callback's `)` closes the call.
void Rewriter::pass_arrow_lambda()
{
    std::vector<Token> out;
    out.reserve(tokens_.size() + 16);

    int i = 0;
    int n = static_cast<int>(tokens_.size());
    while (i < n)
    {
        if (tokens_[i].kind != TokenKind::Arrow2)
        {
            out.push_back(tokens_[i]);
            ++i;
            continue;
        }

        int  pc = prev_code(i);
        bool explicit_cap = pc >= 0 && tokens_[pc].kind == TokenKind::Punct &&
                            tokens_[pc].text == "]";
        std::string arrow_leading = tokens_[i].leading;
        std::string indent = line_indent(i);

        auto emit_call = [&]()
        {
            if (!explicit_cap)
            {
                Token cap;
                cap.kind    = TokenKind::Identifier;
                cap.text    = "[&]";
                cap.leading = arrow_leading;
                out.push_back(cap);
            }
            Token call;
            call.kind    = TokenKind::Punct;
            call.text    = "()";
            call.leading = "";
            out.push_back(call);
        };

        int next = next_code(i);

        // Block body: => { … }
        if (next < n && tokens_[next].kind == TokenKind::Punct && tokens_[next].text == "{")
        {
            emit_call();
            tokens_[next].leading = "\n" + indent;   // Allman: brace on its own line
            ++i;                                     // drop '=>'; '{' emitted later
            continue;
        }

        // Expression / print body — gather up to a terminator.
        bool is_print = next < n && tokens_[next].kind == TokenKind::Identifier &&
                        tokens_[next].text == "p";
        int b = is_print ? next + 1 : i + 1;
        int e = b;
        while (e < n)
        {
            const Token& t = tokens_[e];
            if (t.kind == TokenKind::Punct &&
                (t.text == ";" || t.text == "{" || t.text == "}" ||
                 t.text == "," || t.text == ")"))
            {
                break;
            }
            if (t.kind == TokenKind::End) { break; }
            if (e > b && t.leading.find('\n') != std::string::npos) { break; }
            ++e;
        }
        if (e == b)
        {
            out.push_back(tokens_[i]);   // empty body — leave `=>` alone
            ++i;
            continue;
        }

        emit_call();
        Token ob;
        ob.kind = TokenKind::Punct;
        ob.text = "{";
        ob.leading = "\n" + indent;
        out.push_back(ob);

        if (is_print)
        {
            bool wrap = (e - b) > 1;   // parens only for multi-token exprs
            Token head;
            head.kind = TokenKind::Identifier;
            head.text = wrap ? "std::cout << (" : "std::cout <<";
            head.leading = "\n" + indent + "    ";
            out.push_back(head);
            for (int k = b; k < e; ++k)
            {
                Token t = tokens_[k];
                if (k == b) { t.leading = wrap ? "" : " "; }
                out.push_back(t);
            }
            Token tail;
            tail.kind = TokenKind::Identifier;
            tail.text = wrap ? ") << std::endl;" : " << std::endl;";
            tail.leading = "";
            out.push_back(tail);
            needs_iostream_ = true;
        }
        else
        {
            Token ret;
            ret.kind = TokenKind::Identifier;
            ret.text = "return";
            ret.leading = "\n" + indent + "    ";
            out.push_back(ret);
            for (int k = b; k < e; ++k)
            {
                Token t = tokens_[k];
                if (k == b) { t.leading = " "; }
                out.push_back(t);
            }
            Token sc;
            sc.kind = TokenKind::Punct;
            sc.text = ";";
            sc.leading = "";
            out.push_back(sc);
        }

        Token cb;
        cb.kind = TokenKind::Punct;
        cb.text = "}";
        cb.leading = "\n" + indent;
        out.push_back(cb);

        i = e;   // leave the terminator in the stream
    }
    tokens_ = std::move(out);
}

// Index of the `[` matching the `]` at jb, or -1.
static int match_open_bracket(const std::vector<Token>& toks, int jb)
{
    int depth = 0;
    for (int j = jb; j >= 0; --j)
    {
        if (toks[j].kind == TokenKind::Punct && toks[j].text == "]") { ++depth; }
        else if (toks[j].kind == TokenKind::Punct && toks[j].text == "[")
        {
            --depth;
            if (depth == 0) { return j; }
        }
    }
    return -1;
}

// Index of the `)` matching the `(` at op, or -1.
static int match_close_paren(const std::vector<Token>& toks, int op)
{
    int depth = 0;
    for (int j = op; j < static_cast<int>(toks.size()); ++j)
    {
        if (toks[j].kind == TokenKind::Punct && toks[j].text == "(") { ++depth; }
        else if (toks[j].kind == TokenKind::Punct && toks[j].text == ")")
        {
            --depth;
            if (depth == 0) { return j; }
        }
    }
    return -1;
}

// Concatenated source text of tokens [a, b) (first token's own leading dropped).
static std::string text_range(const std::vector<Token>& toks, int a, int b)
{
    std::string s;
    for (int k = a; k < b; ++k)
    {
        if (k != a) { s += toks[k].leading; }
        s += toks[k].text;
    }
    return s;
}

bool Rewriter::is_stmt_boundary(int p) const
{
    if (p < 0)
    {
        return true;    // start of the stream
    }
    const Token& t = tokens_[p];
    if (t.kind == TokenKind::Punct &&
        (t.text == ";" || t.text == "{" || t.text == "}" || t.text == ":"))
    {
        return true;
    }
    return t.kind == TokenKind::Identifier && (t.text == "else" || t.text == "do");
}

// Walk backward from the operator at `op` over the postfix expression that forms
// its left-hand side: a member chain (`a.b->c`) optionally threaded through call
// `(…)` and subscript `[…]` groups. Sets [ls, le] to the LHS token span.
bool Rewriter::gather_lhs(int op, int& ls, int& le) const
{
    le = prev_code(op);
    if (le < 0)
    {
        return false;
    }
    int j = le;
    while (true)
    {
        const Token& t = tokens_[j];
        if (t.kind == TokenKind::Punct && t.text == ")")
        {
            int o = match_open_paren(tokens_, j);
            if (o < 0) { return false; }
            int pj = prev_code(o);
            if (pj < 0) { return false; }
            j = pj;
            continue;
        }
        if (t.kind == TokenKind::Punct && t.text == "]")
        {
            int o = match_open_bracket(tokens_, j);
            if (o < 0) { return false; }
            int pj = prev_code(o);
            if (pj < 0) { return false; }
            j = pj;
            continue;
        }
        if (t.kind == TokenKind::Identifier || t.kind == TokenKind::DollarIdent)
        {
            int p = prev_code(j);
            if (p >= 0 && tokens_[p].kind == TokenKind::Punct &&
                (tokens_[p].text == "." || tokens_[p].text == "->" || tokens_[p].text == "::"))
            {
                int pp = prev_code(p);
                if (pp < 0) { break; }
                j = pp;
                continue;
            }
            break;
        }
        break;
    }
    ls = j;
    return true;
}

// Gather a right-hand-side expression starting at `start`, respecting nesting.
// Stops at a depth-0 `;` (always), a depth-0 `,` (if stop_comma), an unmatched
// closer `)`/`]`/`}`, end of input, or a new line (if stop_newline). Returns the
// index of the terminator (one past the RHS).
int Rewriter::gather_rhs(int start, bool stop_comma, bool stop_newline) const
{
    int n = static_cast<int>(tokens_.size());
    int depth = 0;
    int e = start;
    while (e < n)
    {
        const Token& t = tokens_[e];
        if (t.kind == TokenKind::Punct && (t.text == "(" || t.text == "[" || t.text == "{"))
        {
            ++depth;
        }
        else if (t.kind == TokenKind::Punct && (t.text == ")" || t.text == "]" || t.text == "}"))
        {
            if (depth == 0) { break; }
            --depth;
        }
        else if (depth == 0 && t.kind == TokenKind::Punct && t.text == ";")
        {
            break;
        }
        else if (depth == 0 && stop_comma && t.kind == TokenKind::Punct && t.text == ",")
        {
            break;
        }
        else if (t.kind == TokenKind::End)
        {
            break;
        }
        if (stop_newline && e > start && t.leading.find('\n') != std::string::npos)
        {
            break;
        }
        ++e;
    }
    return e;
}

// Null-safe access:  base?.m1?.m2 [?? fallback]
// becomes an immediately-invoked lambda that short-circuits on the first null
// pointer (mirrors the playground's makeNullSafeChain):
//
//   ([&]() -> decltype(((base))->m1->…)
//   {
//       auto _shrt_chain_0 = (base);
//       if (!_shrt_chain_0) return <onNull>;
//       … one temp + null check per intermediate hop …
//       return _shrt_chain_N->mLast;
//   }())
//
// onNull is `decltype(...){}` (value-initialised) with no fallback, or
// `static_cast<decltype(...)>(fallback)` when a trailing `?? fallback` is given.
// The member access is NOT outer-parenthesised, so `decltype` yields the member's
// declared (non-reference) type — which is what makes the static_cast/{} valid.
// Runs after the keyword swap and before pass_elvis, consuming its own `??`.
void Rewriter::pass_nullsafe()
{
    std::vector<Token> out;
    out.reserve(tokens_.size() + 16);

    int i = 0;
    int n = static_cast<int>(tokens_.size());
    while (i < n)
    {
        if (tokens_[i].kind != TokenKind::NullSafe)
        {
            out.push_back(tokens_[i]);
            ++i;
            continue;
        }

        // Base = postfix expression to the left of the first `?.`.
        int ls = 0;
        int le = 0;
        if (!gather_lhs(i, ls, le))
        {
            out.push_back(tokens_[i]);
            ++i;
            continue;
        }
        std::string base = text_range(tokens_, ls, le + 1);
        std::string lead = tokens_[ls].leading;
        std::string ind  = line_indent(i);

        // Collect the `?.member` hops.
        std::vector<std::string> members;
        int k = i;
        while (k < n && tokens_[k].kind == TokenKind::NullSafe)
        {
            int m = next_code(k);
            if (m < n && tokens_[m].kind == TokenKind::Identifier)
            {
                members.push_back(tokens_[m].text);
                k = next_code(m);
            }
            else
            {
                break;
            }
        }
        if (members.empty())
        {
            out.push_back(tokens_[i]);
            ++i;
            continue;
        }

        // Optional trailing `?? fallback`.
        bool has_fallback = false;
        std::string fallback;
        int after = k;
        if (k < n && tokens_[k].kind == TokenKind::Elvis)
        {
            int fb = next_code(k);
            int fe = gather_rhs(fb, true, true);
            if (fe > fb)
            {
                has_fallback = true;
                fallback = transpile_fragment(text_range(tokens_, fb, fe));
                after = fe;     // leave the terminator in the stream
            }
        }

        // Build finalExpr / returnType exactly like the playground.
        std::string final_expr = "(" + base + ")";
        for (const std::string& mem : members)
        {
            final_expr = "(" + final_expr + ")->" + mem;
        }
        std::string ret_type = "decltype(" + final_expr + ")";
        std::string on_null  = has_fallback
            ? ("static_cast<" + ret_type + ">(" + fallback + ")")
            : (ret_type + "{}");

        std::string in1 = "\n" + ind + "    ";
        std::string code;
        code += "([&]() -> " + ret_type;
        code += "\n" + ind + "{";
        std::string t0 = "_shrt_chain_" + std::to_string(chain_counter_++);
        code += in1 + "auto " + t0 + " = (" + base + ");";
        code += in1 + "if (!" + t0 + ") return " + on_null + ";";
        std::string cur = t0;
        for (size_t idx = 0; idx + 1 < members.size(); ++idx)
        {
            std::string nt = "_shrt_chain_" + std::to_string(chain_counter_++);
            code += in1 + "auto " + nt + " = " + cur + "->" + members[idx] + ";";
            code += in1 + "if (!" + nt + ") return " + on_null + ";";
            cur = nt;
        }
        code += in1 + "return " + cur + "->" + members.back() + ";";
        code += "\n" + ind + "}())";

        // Replace the already-emitted base span with the IIFE.
        for (int q = 0; q < i - ls && !out.empty(); ++q)
        {
            out.pop_back();
        }
        Token node;
        node.kind    = TokenKind::Identifier;
        node.leading = lead;
        node.text    = code;
        out.push_back(node);

        i = after;
    }
    tokens_ = std::move(out);
}

// Elvis operators (run after the keyword swap, so guards already read
// `return`/`break`/`continue` and any RHS `nil` is already `nullptr`):
//   LHS ?? return;        → if (!(LHS)) return;
//   LHS ?? return expr;   → if (!(LHS)) return expr;
//   LHS ?? break/continue;→ if (!(LHS)) break;  / continue;
//   LHS ?? call(...);     → if (!(LHS)) call(...);   (only at statement position)
//   LHS ?? rhs            → ((LHS) ? (LHS) : (rhs))   (expression fallback)
//   LHS ??= rhs;          → LHS = (LHS) ? (LHS) : (rhs);
void Rewriter::pass_elvis()
{
    // Process the RIGHTMOST `??`/`??=` first, replacing its span in place. By the
    // time an outer/earlier operator gathers its RHS, any inner one to the right
    // is already a single transformed node — so chains (`a ?? b ?? c`) and nested
    // operators (`a ?? foo(x ?? y)`) come out correct rather than leaving a stray
    // `??` in captured text.
    while (true)
    {
        int n = static_cast<int>(tokens_.size());
        int i = -1;
        for (int q = n - 1; q >= 0; --q)
        {
            if (tokens_[q].kind == TokenKind::Elvis || tokens_[q].kind == TokenKind::ElvisAssign)
            {
                i = q;
                break;
            }
        }
        if (i < 0)
        {
            break;
        }

        TokenKind k = tokens_[i].kind;
        int ls = 0;
        int le = 0;
        if (!gather_lhs(i, ls, le))
        {
            tokens_[i].kind = TokenKind::Punct;   // malformed — demote, don't loop
            continue;
        }
        std::string lhs  = text_range(tokens_, ls, le + 1);
        std::string lead = tokens_[ls].leading;

        std::string node_text;
        int end_exclusive = i + 1;   // first index past the consumed span

        if (k == TokenKind::ElvisAssign)
        {
            int e = gather_rhs(i + 1, false, false);
            std::string rhs = text_range(tokens_, i + 1, e);
            bool has_semi = e < n && tokens_[e].kind == TokenKind::Punct && tokens_[e].text == ";";
            node_text = lhs + " = (" + lhs + ") ? (" + lhs + ") : (" + rhs + ")" +
                        (has_semi ? ";" : "");
            end_exclusive = has_semi ? e + 1 : e;
        }
        else
        {
            int  nx       = next_code(i);
            bool boundary = is_stmt_boundary(prev_code(ls));
            bool done     = false;

            // return / break / continue guards
            if (nx < n && tokens_[nx].kind == TokenKind::Identifier && tokens_[nx].text == "return")
            {
                int ar = next_code(nx);
                if (ar < n && tokens_[ar].kind == TokenKind::Punct && tokens_[ar].text == ";")
                {
                    node_text = "if (!(" + lhs + ")) return;";
                    end_exclusive = ar + 1;
                }
                else
                {
                    int e = gather_rhs(ar, false, false);
                    std::string expr = text_range(tokens_, ar, e);
                    bool has_semi = e < n && tokens_[e].kind == TokenKind::Punct && tokens_[e].text == ";";
                    node_text = "if (!(" + lhs + ")) return " + expr + ";";
                    end_exclusive = has_semi ? e + 1 : e;
                }
                done = true;
            }
            else if (nx < n && tokens_[nx].kind == TokenKind::Identifier &&
                     (tokens_[nx].text == "break" || tokens_[nx].text == "continue"))
            {
                int ar = next_code(nx);
                if (ar < n && tokens_[ar].kind == TokenKind::Punct && tokens_[ar].text == ";")
                {
                    node_text = "if (!(" + lhs + ")) " + tokens_[nx].text + ";";
                    end_exclusive = ar + 1;
                    done = true;
                }
            }

            // call-statement guard:  ident(...) ;   — only at statement position
            if (!done && boundary && nx < n && tokens_[nx].kind == TokenKind::Identifier)
            {
                int after_id = next_code(nx);
                if (after_id < n && tokens_[after_id].kind == TokenKind::Punct &&
                    tokens_[after_id].text == "(")
                {
                    int cp = match_close_paren(tokens_, after_id);
                    if (cp >= 0)
                    {
                        int ac = next_code(cp);
                        if (ac < n && tokens_[ac].kind == TokenKind::Punct && tokens_[ac].text == ";")
                        {
                            std::string call = text_range(tokens_, nx, cp + 1);
                            node_text = "if (!(" + lhs + ")) " + call + ";";
                            end_exclusive = ac + 1;
                            done = true;
                        }
                    }
                }
            }

            // expression fallback form
            if (!done)
            {
                int e = gather_rhs(i + 1, true, true);
                std::string rhs = text_range(tokens_, i + 1, e);
                node_text = "((" + lhs + ") ? (" + lhs + ") : (" + rhs + "))";
                end_exclusive = e;   // leave the terminator in the stream
            }
        }

        Token node;
        node.kind    = TokenKind::Identifier;
        node.leading = lead;
        node.text    = node_text;
        tokens_.erase(tokens_.begin() + ls, tokens_.begin() + end_exclusive);
        tokens_.insert(tokens_.begin() + ls, node);
    }
}

// Shift every line of `body` after the first by `shift` leading spaces (negative
// removes). Used to re-nest a captured `{ … }` block under generated wrapper
// code. Space-indented input only; a raw string spanning lines would be a rare
// edge that this would disturb.
static std::string reindent(const std::string& body, int shift)
{
    if (shift == 0)
    {
        return body;
    }
    std::string out;
    out.reserve(body.size());
    for (size_t i = 0; i < body.size(); ++i)
    {
        out.push_back(body[i]);
        if (body[i] == '\n')
        {
            size_t j = i + 1;
            int spaces = 0;
            while (j < body.size() && body[j] == ' ')
            {
                ++spaces;
                ++j;
            }
            int adjusted = spaces + shift;
            if (adjusted < 0)
            {
                adjusted = 0;
            }
            out.append(static_cast<size_t>(adjusted), ' ');
            i = j - 1;   // skip the original run of spaces
        }
    }
    return out;
}

// Index of the `}` matching the `{` at op, or -1.
static int match_close_brace(const std::vector<Token>& toks, int op)
{
    int depth = 0;
    for (int j = op; j < static_cast<int>(toks.size()); ++j)
    {
        if (toks[j].kind == TokenKind::Punct && toks[j].text == "{") { ++depth; }
        else if (toks[j].kind == TokenKind::Punct && toks[j].text == "}")
        {
            --depth;
            if (depth == 0) { return j; }
        }
    }
    return -1;
}

// defer <stmt>;  →  a uniquely-named ScopeGuard whose destructor runs the work
// at scope exit (LIFO). The block form `defer { … }` wraps the whole block.
// Runs after the keyword swap (so `defer d ptr;` already reads `delete ptr`)
// and after the operator passes. Injects the ScopeGuard helper once if used.
void Rewriter::pass_defer()
{
    std::vector<Token> out;
    out.reserve(tokens_.size() + 16);

    int  counter = 0;
    bool found   = false;
    int  i = 0;
    int  n = static_cast<int>(tokens_.size());
    while (i < n)
    {
        const Token& tok = tokens_[i];
        bool is_defer = tok.kind == TokenKind::Identifier && tok.text == "defer";
        if (is_defer)
        {
            int p = prev_code(i);
            if (p >= 0 && (tokens_[p].kind == TokenKind::NullSafe ||
                           (tokens_[p].kind == TokenKind::Punct &&
                            (tokens_[p].text == "." || tokens_[p].text == "->" ||
                             tokens_[p].text == "::"))))
            {
                is_defer = false;
            }
        }
        if (!is_defer)
        {
            out.push_back(tok);
            ++i;
            continue;
        }

        std::string ind = line_indent(i);
        std::string v   = "_shrt_defer_" + std::to_string(counter);
        int nx = next_code(i);

        bool        block = nx < n && tokens_[nx].kind == TokenKind::Punct &&
                            tokens_[nx].text == "{";
        std::string text;
        int         advance = i + 1;
        bool        ok = false;

        if (block)
        {
            int close = match_close_brace(tokens_, nx);
            if (close >= 0)
            {
                std::string body = text_range(tokens_, nx, close + 1);   // {...}
                // Re-nest the block one level under the generated `[&]()`.
                int shift = static_cast<int>(ind.size() + 4) -
                            static_cast<int>(line_indent(nx).size());
                body = reindent(body, shift);
                text = "shrt_runtime::ScopeGuard " + v + "\n" + ind + "{\n" +
                       ind + "    [&]()\n" + ind + "    " + body + "\n" + ind + "};";
                advance = close + 1;
                ok = true;
            }
        }
        else
        {
            int e = i + 1;
            while (e < n && !(tokens_[e].kind == TokenKind::Punct && tokens_[e].text == ";") &&
                   tokens_[e].kind != TokenKind::End)
            {
                ++e;
            }
            if (e < n && tokens_[e].kind == TokenKind::Punct && tokens_[e].text == ";" && e > i + 1)
            {
                std::string body = trim(text_range(tokens_, i + 1, e));
                text = "shrt_runtime::ScopeGuard " + v + "\n" + ind + "{\n" +
                       ind + "    [&]()\n" + ind + "    {\n" +
                       ind + "        " + body + ";\n" + ind + "    }\n" + ind + "};";
                advance = e + 1;
                ok = true;
            }
        }

        if (!ok)
        {
            out.push_back(tok);
            ++i;
            continue;
        }

        found = true;
        ++counter;
        Token t;
        t.kind    = TokenKind::Identifier;
        t.leading = tok.leading;
        t.text    = text;
        out.push_back(t);
        i = advance;
    }
    tokens_ = std::move(out);

    if (found)
    {
        inject_runtime();
    }
}

void Rewriter::inject_runtime()
{
    for (const Token& t : tokens_)
    {
        if (t.text.find("struct ScopeGuard") != std::string::npos)
        {
            return;     // helper already present
        }
    }

    std::string decl =
        "namespace shrt_runtime\n{\ntemplate<class F>\nstruct ScopeGuard\n{\n"
        "    F func;\n    ScopeGuard(F fn)\n        : func(static_cast<F&&>(fn))\n"
        "    {\n    }\n    ~ScopeGuard()\n    {\n        func();\n    }\n"
        "    ScopeGuard(const ScopeGuard&) = delete;\n"
        "    ScopeGuard& operator=(const ScopeGuard&) = delete;\n};\n"
        "template<class F>\nScopeGuard(F) -> ScopeGuard<F>;\n}";

    int last = -1;
    for (int i = 0; i < static_cast<int>(tokens_.size()); ++i)
    {
        if (tokens_[i].text.rfind("#include", 0) == 0)
        {
            last = i;
        }
    }

    Token t;
    t.kind = TokenKind::Identifier;
    if (last >= 0)
    {
        t.leading = "\n";
        t.text    = decl;
        tokens_.insert(tokens_.begin() + last + 1, t);
    }
    else
    {
        t.leading = "";
        t.text    = decl + "\n";
        tokens_.insert(tokens_.begin(), t);
    }
}

void Rewriter::inject_include(const std::string& directive)
{
    for (const Token& t : tokens_)
    {
        if (t.text.find(directive) != std::string::npos)
        {
            return;     // already present (e.g. user wrote the include)
        }
    }

    int last = -1;
    for (int i = 0; i < static_cast<int>(tokens_.size()); ++i)
    {
        if (tokens_[i].text.rfind("#include", 0) == 0)
        {
            last = i;
        }
    }

    Token inc;
    inc.kind = TokenKind::Identifier;
    if (last >= 0)
    {
        inc.leading = "\n";
        inc.text    = directive;
        tokens_.insert(tokens_.begin() + last + 1, inc);
    }
    else
    {
        inc.leading = "";
        inc.text    = directive + "\n";
        tokens_.insert(tokens_.begin(), inc);
    }
}

void Rewriter::pass_auto_includes()
{
    if (needs_iostream_)
    {
        inject_include("#include <iostream>");
    }
    if (needs_format_)
    {
        inject_include("#include <format>");
    }
}

std::string Rewriter::emit() const
{
    std::string out;
    for (const Token& t : tokens_)
    {
        out += t.leading;
        out += t.text;
    }
    return out;
}

// Emit `#line N "file"` directives so compiler diagnostics on the generated C++
// map back to the original `.shrt`. A directive is written only when the next
// source line a token reports does not match the running expectation — i.e.
// after a rewrite that added or removed lines. Synthesized tokens carry no
// source line (0) and are skipped; the next real-source token re-syncs.
std::string Rewriter::emit_mapped(const std::string& file) const
{
    // `#line "..."` is a string literal: backslashes would start escapes, so
    // normalize Windows separators to forward slashes (valid on every compiler).
    std::string safe;
    for (char c : file)
    {
        safe += (c == '\\') ? '/' : c;
    }

    std::string out;
    int expected = 0;   // next source line we expect to see at a line start
    for (const Token& t : tokens_)
    {
        bool starts_line = out.empty() || t.leading.find('\n') != std::string::npos;
        if (t.line > 0 && t.kind != TokenKind::End && starts_line)
        {
            if (t.line != expected)
            {
                size_t nl = t.leading.rfind('\n');
                if (nl != std::string::npos)
                {
                    out += t.leading.substr(0, nl + 1);                  // through the newline
                    out += "#line " + std::to_string(t.line) + " \"" + safe + "\"\n";
                    out += t.leading.substr(nl + 1);                     // re-apply the indent
                }
                else
                {
                    out += "#line " + std::to_string(t.line) + " \"" + safe + "\"\n";
                    out += t.leading;
                }
                out += t.text;
                expected = t.line + 1;
                continue;
            }
            expected = t.line + 1;
        }
        out += t.leading;
        out += t.text;
    }
    return out;
}

std::string Rewriter::run(bool line_directives, const std::string& file)
{
    pass_includes();        // i/li → #include (before swap, consumes targets)
    pass_dollar_ident();    // $vector → std::vector
    pass_interp_string();   // $"a {e}" → std::format("a {}", e)
    pass_print();           // p expr; → std::cout << expr << std::endl;
    pass_which();           // which v { 1: … } → switch (v) { case 1: … }
    pass_optional_parens(); // if cond { … } → if (cond) { … }  (before w→while)
    pass_arrow_exprbody();  // ) => expr; → ) { return expr; }
    pass_arrow_lambda();    // => {…}/expr → [&]()\n{…}  (standalone lambdas)
    pass_keyword_swap();    // c/s/e/a/f/… → class/struct/…
    pass_nullsafe();        // a?.b?.c [?? fb] → IIFE (before elvis; eats its ??)
    pass_elvis();           // ?? / ??= → guard stmt or ternary (keywords swapped)
    pass_defer();           // defer stmt; / defer {…} → ScopeGuard (+ helper)
    pass_auto_includes();   // inject <iostream>/<format> for features used
    return line_directives ? emit_mapped(file) : emit();
}

} // namespace shrt
