// main.cpp — CLI entry point for the SHRT transpiler.
//
// Usage:
//   shrt <input.shrt>                  transpile to stdout
//   shrt <input.shrt> -o <out.cpp>     transpile to a file
//   shrt <input.shrt> -g               emit #line directives → errors map to .shrt
//   shrt <input.shrt> --line-directives  (long form of -g)
//   shrt <input.shrt> --tokens         dump the token stream (debug)
//   shrt <input.shrt> --roundtrip      re-emit source from tokens (lexer check)
//   shrt <input.shrt> --no-rule1       skip the single-letter-identifier check

#include "lexer.h"
#include "mascot.h"
#include "rewriter.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace
{

constexpr const char* version = "0.1.2";

void print_help(std::ostream& out)
{
    shrt::mascot::print(out);
    out << "\nSHRT " << version << " — source-to-source C++ transpiler\n\n"
           "usage: shrt <input.shrt> [-o out.cpp] [-g|--line-directives]\n"
           "            [--tokens] [--roundtrip] [--no-rule1]\n\n"
           "options:\n"
           "  -o <file>            write generated C++ to a file\n"
           "  -g, --line-directives  map compiler diagnostics to SHRT lines\n"
           "  --tokens             print the lexer token stream\n"
           "  --roundtrip          re-emit the token stream without rewriting\n"
           "  --no-rule1           allow single-letter user identifiers\n"
           "  --no-animation       disable the interactive loading mascot\n"
           "  -h, --help           show this help\n"
           "  --version            show the installed version\n";
}

std::string read_file(const std::string& path, bool& ok)
{
    std::ifstream in(path, std::ios::binary);
    if (!in)
    {
        ok = false;
        return {};
    }
    std::ostringstream ss;
    ss << in.rdbuf();
    ok = true;
    return ss.str();
}

// Concatenate every token's leading trivia and text. With no rewriting this
// reproduces the input byte-for-byte — the invariant the lexer must uphold.
std::string emit(const std::vector<shrt::Token>& tokens)
{
    std::string out;
    for (const shrt::Token& t : tokens)
    {
        out += t.leading;
        out += t.text;
    }
    return out;
}

void dump_tokens(const std::vector<shrt::Token>& tokens)
{
    for (const shrt::Token& t : tokens)
    {
        std::cout << "[" << t.line << ":" << t.col << "] "
                  << shrt::kind_name(t.kind);
        if (!t.text.empty())
        {
            std::cout << "  '" << t.text << "'";
        }
        std::cout << "\n";
    }
}

} // namespace

int main(int argc, char** argv)
{
    std::vector<std::string> args(argv + 1, argv + argc);
    if (args.empty())
    {
        print_help(std::cerr);
        return 2;
    }

    if (args.size() == 1 && (args[0] == "-h" || args[0] == "--help"))
    {
        print_help(std::cout);
        return 0;
    }
    if (args.size() == 1 && args[0] == "--version")
    {
        std::cout << "shrt " << version << "\n";
        return 0;
    }

    std::string input;
    std::string output;
    bool tokens_mode    = false;
    bool roundtrip_mode = false;
    bool no_rule1       = false;
    bool line_directives = false;
    bool no_animation   = false;

    for (size_t i = 0; i < args.size(); ++i)
    {
        const std::string& a = args[i];
        if (a == "-o" && i + 1 < args.size())
        {
            output = args[++i];
        }
        else if (a == "--tokens")
        {
            tokens_mode = true;
        }
        else if (a == "--roundtrip")
        {
            roundtrip_mode = true;
        }
        else if (a == "--no-rule1")
        {
            no_rule1 = true;
        }
        else if (a == "--line-directives" || a == "-g")
        {
            line_directives = true;
        }
        else if (a == "--no-animation")
        {
            no_animation = true;
        }
        else if (!a.empty() && a[0] == '-')
        {
            std::cerr << "unknown option: " << a << "\n";
            return 2;
        }
        else
        {
            input = a;
        }
    }

    if (input.empty())
    {
        std::cerr << "error: no input file\n";
        return 2;
    }

    if (!no_animation && !output.empty())
    {
        shrt::mascot::play(input);
    }

    bool ok = false;
    std::string source = read_file(input, ok);
    if (!ok)
    {
        std::cerr << "error: cannot read " << input << "\n";
        return 1;
    }

    shrt::Lexer lexer(source);
    std::vector<shrt::Token> tokens = lexer.tokenize();

    if (tokens_mode)
    {
        dump_tokens(tokens);
        return 0;
    }

    // Rule #1 validation runs on the original tokens, before any rewriting.
    if (!no_rule1 && !roundtrip_mode)
    {
        std::vector<shrt::Diagnostic> diags = shrt::check_rule1(tokens);
        if (!diags.empty())
        {
            for (const shrt::Diagnostic& d : diags)
            {
                std::cerr << input << ":" << d.line << ":" << d.col
                          << ": error: " << d.message << "\n";
            }
            std::cerr << diags.size() << " error(s); pass --no-rule1 to bypass.\n";
            return 1;
        }
    }

    // --roundtrip re-emits straight from tokens (lexer losslessness check);
    // the default path runs the rewriter passes to produce C++.
    std::string result;
    if (roundtrip_mode)
    {
        result = emit(tokens);
    }
    else
    {
        shrt::Rewriter rewriter(tokens);
        result = rewriter.run(line_directives, input);
    }

    if (output.empty())
    {
        std::cout << result;
    }
    else
    {
        std::ofstream out(output, std::ios::binary);
        if (!out)
        {
            std::cerr << "error: cannot write " << output << "\n";
            return 1;
        }
        out << result;
    }
    return 0;
}
