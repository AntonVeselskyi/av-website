// lexer.cpp — implementation of the SHRT scanner. See lexer.h for the rationale.

#include "lexer.h"
#include <cctype>

namespace shrt
{

static bool is_ident_start(char c)
{
    return std::isalpha(static_cast<unsigned char>(c)) || c == '_';
}

static bool is_ident_cont(char c)
{
    return std::isalnum(static_cast<unsigned char>(c)) || c == '_';
}

static bool is_space(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\f' || c == '\v';
}

char Lexer::advance()
{
    char c = src_[pos_++];
    if (c == '\n')
    {
        line_ += 1;
        col_   = 1;
    }
    else
    {
        col_ += 1;
    }
    return c;
}

std::string Lexer::scan_leading()
{
    std::string out;
    while (!at_end() && is_space(peek()))
    {
        out.push_back(advance());
    }
    return out;
}

Token Lexer::make(TokenKind kind, std::string text, std::string leading,
                  int line, int col)
{
    Token t;
    t.kind    = kind;
    t.text    = std::move(text);
    t.leading = std::move(leading);
    t.line    = line;
    t.col     = col;
    return t;
}

std::vector<Token> Lexer::tokenize()
{
    std::vector<Token> tokens;
    while (true)
    {
        std::string leading = scan_leading();
        if (at_end())
        {
            tokens.push_back(make(TokenKind::End, "", std::move(leading), line_, col_));
            break;
        }
        tokens.push_back(scan_token(std::move(leading)));
    }
    return tokens;
}

Token Lexer::scan_token(std::string leading)
{
    int line = line_;
    int col  = col_;
    char c   = peek();

    // Comments.
    if (c == '/' && peek(1) == '/')
    {
        std::string text;
        while (!at_end() && peek() != '\n')
        {
            text.push_back(advance());
        }
        return make(TokenKind::LineComment, std::move(text), std::move(leading), line, col);
    }
    if (c == '/' && peek(1) == '*')
    {
        std::string text;
        text.push_back(advance());   // '/'
        text.push_back(advance());   // '*'
        while (!at_end())
        {
            if (peek() == '*' && peek(1) == '/')
            {
                text.push_back(advance());
                text.push_back(advance());
                break;
            }
            text.push_back(advance());
        }
        return make(TokenKind::BlockComment, std::move(text), std::move(leading), line, col);
    }

    // Raw string R"(...)" — only when an R is immediately followed by a quote.
    if (c == 'R' && peek(1) == '"')
    {
        return scan_raw_string(std::move(leading), line, col);
    }

    if (c == '"')
    {
        return scan_string(std::move(leading), line, col);
    }
    if (c == '\'')
    {
        return scan_char(std::move(leading), line, col);
    }
    if (c == '$')
    {
        return scan_dollar(std::move(leading), line, col);
    }
    if (std::isdigit(static_cast<unsigned char>(c)))
    {
        return scan_number(std::move(leading), line, col);
    }
    if (is_ident_start(c))
    {
        return scan_identifier(std::move(leading), line, col);
    }

    // SHRT-significant operators.
    if (c == '?')
    {
        if (peek(1) == '?' && peek(2) == '=')
        {
            advance(); advance(); advance();
            return make(TokenKind::ElvisAssign, "?\?=", std::move(leading), line, col);
        }
        if (peek(1) == '?')
        {
            advance(); advance();
            return make(TokenKind::Elvis, "??", std::move(leading), line, col);
        }
        if (peek(1) == '.')
        {
            advance(); advance();
            return make(TokenKind::NullSafe, "?.", std::move(leading), line, col);
        }
        advance();
        return make(TokenKind::Punct, "?", std::move(leading), line, col);
    }
    // `<=>` (spaceship) must be matched before `=>`, otherwise its trailing `=>`
    // is mistaken for the SHRT fat-arrow and the operator is mangled.
    if (c == '<' && peek(1) == '=' && peek(2) == '>')
    {
        advance(); advance(); advance();
        return make(TokenKind::Punct, "<=>", std::move(leading), line, col);
    }
    if (c == '=' && peek(1) == '>')
    {
        advance(); advance();
        return make(TokenKind::Arrow2, "=>", std::move(leading), line, col);
    }

    // `::` and `->` are kept whole (not because re-emission needs it, but so the
    // rewriter's member/qualified-access guards are a single-token check).
    if (c == ':' && peek(1) == ':')
    {
        advance(); advance();
        return make(TokenKind::Punct, "::", std::move(leading), line, col);
    }
    if (c == '-' && peek(1) == '>')
    {
        advance(); advance();
        return make(TokenKind::Punct, "->", std::move(leading), line, col);
    }

    // Anything else: a single punctuation char. Genuine C++ multi-char operators
    // (::, ->, <<, ==, …) come through as adjacent Punct tokens and re-emit
    // identically because no whitespace is inserted between tokens.
    advance();
    return make(TokenKind::Punct, std::string(1, c), std::move(leading), line, col);
}

Token Lexer::scan_identifier(std::string leading, int line, int col)
{
    std::string text;
    while (!at_end() && is_ident_cont(peek()))
    {
        text.push_back(advance());
    }
    return make(TokenKind::Identifier, std::move(text), std::move(leading), line, col);
}

Token Lexer::scan_number(std::string leading, int line, int col)
{
    std::string text;
    char prev = '\0';
    text.push_back(prev = advance());           // first digit
    while (!at_end())
    {
        char c = peek();
        if (is_ident_cont(c) || c == '.' || c == '\'')
        {
            text.push_back(prev = advance());
        }
        else if ((c == '+' || c == '-') &&
                 (prev == 'e' || prev == 'E' || prev == 'p' || prev == 'P'))
        {
            text.push_back(prev = advance());   // exponent sign
        }
        else
        {
            break;
        }
    }
    return make(TokenKind::Number, std::move(text), std::move(leading), line, col);
}

Token Lexer::scan_string(std::string leading, int line, int col)
{
    std::string text;
    text.push_back(advance());                  // opening "
    while (!at_end())
    {
        char c = advance();
        text.push_back(c);
        if (c == '\\' && !at_end())
        {
            text.push_back(advance());          // escaped char, keep verbatim
        }
        else if (c == '"')
        {
            break;
        }
    }
    return make(TokenKind::StringLit, std::move(text), std::move(leading), line, col);
}

Token Lexer::scan_char(std::string leading, int line, int col)
{
    std::string text;
    text.push_back(advance());                  // opening '
    while (!at_end())
    {
        char c = advance();
        text.push_back(c);
        if (c == '\\' && !at_end())
        {
            text.push_back(advance());
        }
        else if (c == '\'')
        {
            break;
        }
    }
    return make(TokenKind::CharLit, std::move(text), std::move(leading), line, col);
}

Token Lexer::scan_raw_string(std::string leading, int line, int col)
{
    // R"delim( ... )delim"  — capture the delimiter so we stop at the right place.
    std::string text;
    text.push_back(advance());                  // R
    text.push_back(advance());                  // opening "
    std::string delim;
    while (!at_end() && peek() != '(')
    {
        char c = advance();
        delim.push_back(c);
        text.push_back(c);
    }
    if (!at_end())
    {
        text.push_back(advance());              // (
    }
    std::string closing = ")" + delim + "\"";
    while (!at_end())
    {
        // Does the closing sequence start here?
        bool match = true;
        for (size_t k = 0; k < closing.size(); ++k)
        {
            if (peek(k) != closing[k])
            {
                match = false;
                break;
            }
        }
        if (match)
        {
            for (size_t k = 0; k < closing.size(); ++k)
            {
                text.push_back(advance());
            }
            break;
        }
        text.push_back(advance());
    }
    return make(TokenKind::RawString, std::move(text), std::move(leading), line, col);
}

Token Lexer::scan_dollar(std::string leading, int line, int col)
{
    advance();                                  // consume '$'

    // $"..." — interpolated string. Keep the leading '$' in the text.
    if (peek() == '"')
    {
        std::string text = "$";
        text.push_back(advance());              // opening "
        while (!at_end())
        {
            char c = advance();
            text.push_back(c);
            if (c == '\\' && !at_end())
            {
                text.push_back(advance());
            }
            else if (c == '"')
            {
                break;
            }
        }
        return make(TokenKind::InterpString, std::move(text), std::move(leading), line, col);
    }

    // $ident — std:: shorthand. Text keeps the '$' so the rewriter knows.
    if (is_ident_start(peek()))
    {
        std::string text = "$";
        while (!at_end() && is_ident_cont(peek()))
        {
            text.push_back(advance());
        }
        return make(TokenKind::DollarIdent, std::move(text), std::move(leading), line, col);
    }

    // Lone '$' — not valid SHRT, but pass it through rather than crash.
    return make(TokenKind::Punct, "$", std::move(leading), line, col);
}

const char* kind_name(TokenKind kind)
{
    switch (kind)
    {
        case TokenKind::End:          return "End";
        case TokenKind::Identifier:   return "Identifier";
        case TokenKind::Number:       return "Number";
        case TokenKind::StringLit:    return "StringLit";
        case TokenKind::CharLit:      return "CharLit";
        case TokenKind::RawString:    return "RawString";
        case TokenKind::InterpString: return "InterpString";
        case TokenKind::DollarIdent:  return "DollarIdent";
        case TokenKind::LineComment:  return "LineComment";
        case TokenKind::BlockComment: return "BlockComment";
        case TokenKind::Elvis:        return "Elvis";
        case TokenKind::ElvisAssign:  return "ElvisAssign";
        case TokenKind::NullSafe:     return "NullSafe";
        case TokenKind::Arrow2:       return "Arrow2";
        case TokenKind::Punct:        return "Punct";
    }
    return "?";
}

} // namespace shrt
