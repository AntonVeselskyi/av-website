# SHRT

**SHRT** is a tiny programming language that is syntax sugar over C++. A `.shrt`
file is transpiled to plain C++ (`*.shrt.cpp`) and then handed to your normal
compiler. Every valid C++ program is already a valid SHRT program — SHRT only
*adds* shorter ways to write the same thing.

```shrt
i iostream
i vector

s Point
{
    int px;
    int py;

    int sum() k => px + py;          // expression body
};

int main()
{
    a points = $vector<Point>{ {1, 2}, {3, 4} };

    f (k Point& pt : points)
    {
        p $"({pt.px}, {pt.py}) -> {pt.sum()}";   // interpolated print
    }
    r 0;
}
```

transpiles to:

```cpp
#include <iostream>
#include <vector>
#include <format>

struct Point
{
    int px;
    int py;

    int sum() const
    {
        return px + py;
    }
};

int main()
{
    auto points = std::vector<Point>{ {1, 2}, {3, 4} };

    for (const Point& pt : points)
    {
        std::cout << std::format("({}, {}) -> {}", pt.px, pt.py, pt.sum()) << std::endl;
    }
    return 0;
}
```

See **[spec.md](spec.md)** for the full language definition.

## Features

| SHRT | C++ |
|------|-----|
| `i name` / `li name` | `#include <name>` / `#include "name"` |
| `c`/`s`/`e`/`a`/`f`/`w`/`el`/`v`/`n`/`u`/`k`/`d`/`o`/`r`/`b` | `class`/`struct`/`enum class`/`auto`/`for`/`while`/`else`/`virtual`/`namespace`/`using`/`const`/`delete`/`override`/`return`/`break` |
| `cont`/`ke`/`op`/`pub`/`pri`/`pro` | `continue`/`constexpr`/`operator`/`public`/`private`/`protected` |
| `$Ident` | `std::Ident` |
| `$"a {x} b"` | `std::format("a {} b", x)` (auto-includes `<format>`) |
| `p expr;` | `std::cout << expr << std::endl;` (auto-includes `<iostream>`) |
| `which v { 1: … }` | `switch (v) { case 1: … }` |
| `if cond { … }` | `if (cond) { … }` (optional parens) |
| `) => expr;` | `) { return expr; }` (expression body) |
| `=> expr` / `=> { … }` | `[&]() { return expr; }` / `[&]() { … }` (lambda) |
| `a ?? b` / `a ?? r;` | `((a) ? (a) : (b))` / `if (!(a)) return;` (Elvis) |
| `a ??= b;` | `a = (a) ? (a) : (b);` |
| `a?.b?.c` | null-safe chain (IIFE, short-circuits on null) |
| `defer stmt;` / `defer { … }` | RAII scope guard running at scope exit (LIFO) |

**Rule #1:** user-defined names must be 2+ characters — single letters belong to
the language. `T`/`F` and template parameters are exempt. The transpiler reports
violations with `file:line:col` diagnostics.

## Build

```sh
cmake -S . -B build
cmake --build build
```

Produces the `shrt` CLI. (Requires a C++20 compiler. The current dev machine has
no local toolchain, so milestones are verified by compiling on the
[Compiler Explorer](https://godbolt.org) API instead — see `tools/`.)

## Usage

```sh
shrt input.shrt                 # transpile to stdout
shrt input.shrt -o out.cpp      # transpile to a file
shrt input.shrt -g              # emit #line directives → compiler errors map to .shrt
shrt --help                     # command reference
shrt --version                  # installed version
shrt input.shrt --tokens        # debug: dump the lexer token stream
shrt input.shrt --roundtrip     # debug: re-emit source from tokens (lossless check)
shrt input.shrt --no-rule1      # skip the single-letter-identifier check
shrt input.shrt -o out.cpp --no-animation  # suppress the interactive mascot
```

With `-g` (`--line-directives`), the emitted C++ carries `#line N "input.shrt"`
markers so a compiler error on the generated file points back to the original
`.shrt` line — directives are inserted only where a rewrite shifted the line
count, so contiguous regions stay clean.

## How it works

SHRT owns its front end and uses your C++ compiler as the back end — the same
model as TypeScript→JS or Sass→CSS:

```
.shrt → [lexer] → tokens → [rewriter: ~12 small passes] → [emit] → .shrt.cpp → clang/gcc
```

The lexer classifies comments, all string/char/raw/interpolated literals,
`$ident`, the SHRT operators, numbers, identifiers, and punctuation into distinct
token kinds. That is the key advantage over the regex prototype in the web
playground: a `c` token is unambiguously the `class` keyword and never a `c`
inside a comment, string, or longer identifier. Whitespace rides along as each
token's *leading* trivia, so re-emitting `leading + text` reproduces the source
byte-for-byte and rewrites only touch the tokens that differ — the user's layout
(Allman braces and all) is preserved. See **[FAQ.md](FAQ.md)** for the
architecture rationale and **[PROGRESS.md](PROGRESS.md)** for the per-pass design
log.

## Layout

```
src/        token.h, lexer.{h,cpp}, rewriter.{h,cpp}, main.cpp   the transpiler
examples/   per-feature demo .shrt programs
tests/      golden inputs (the 7 web-playground programs)
tools/      godbolt-based checkers (no local compiler needed):
              transpile_check.py   transpile one file + compile the output
              golden_check.py      transpile + compile every tests/*.shrt
              roundtrip_check.py   verify the lexer is lossless
              extract_examples.py  pull the playground programs into tests/
editors/    vscode/ · visual-studio/ · vim/   syntax highlighting, one per editor
spec.md · FAQ.md · TODO.md · PROGRESS.md   language + design docs
```

## Testing

```sh
python tools/golden_check.py     # transpile + compile all 7 golden programs
```

All 7 playground programs (including the everything-at-once "Grand Tour" and the
two game programs) transpile and compile on C++26.

## Editor support

Syntax highlighting that layers SHRT tokens over C++, one folder per editor —
each self-contained with its own install README:

- **VS Code syntax** — [editors/vscode/](editors/vscode/README.md) (language
  detection and a TextMate grammar over the built-in `source.cpp`)
- **VS Code build & run** — [editors/vscode-run/](editors/vscode-run/README.md)
  (independent compile and compile-and-run commands for the active file)
- **Visual Studio** — [editors/visual-studio/](editors/visual-studio/README.md)
  (the same grammar + `fileTypes`, dropped into VS's TextMate folder)
- **Vim / Neovim** — [editors/vim/](editors/vim/README.md) (`syntax/shrt.vim`
  layered on the bundled C++ syntax, plus `ftdetect`)

## Status

Feature-complete against the spec, with the rule-#1 validator and golden tests in
place. Optional future work (source maps, an Allman pretty-printer pass, a
clangd-backed LSP) is listed at the end of [PROGRESS.md](PROGRESS.md).
