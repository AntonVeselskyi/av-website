# shrt language spec

shrt is a transpiler (source-to-source compiler) that converts `.shrt` files into valid C++ before compilation.
It is syntax sugar on top of C++ — all standard C++ is valid inside `.shrt` files.

---

## File extensions

| Extension | Purpose |
|-----------|---------|
| `.shrt` | shrt source file |
| `.shrt.cpp` | intermediate transpiled output |

---

## Rule #1 — Single-letter identifiers are reserved

User-defined variable, function, and type names must be **2+ characters**.
Single letters belong to the language exclusively.

Exceptions:
- Template type parameters (`T`, `U`, etc.) are exempt — template syntax is untouched
- `T` and `F` are NOT reserved — use `true` and `false`

---

## Includes

```
i vector          →   #include <vector>        (system include)
li path/foo.h     →   #include "path/foo.h"    (local include)
```

---

## std:: shorthand

Prefix any identifier with `$` to implicitly prepend `std::`.

```
$vector<int>      →   std::vector<int>
$string           →   std::string
$cout             →   std::cout
```

---

## Keyword map

| shrt | C++ | notes |
|------|-----|-------|
| `i` | `#include <...>` | system include |
| `li` | `#include "..."` | local include |
| `c` | `class` | |
| `s` | `struct` | |
| `e` | `enum` | |
| `a` | `auto` | |
| `f` | `for` | |
| `w` | `while` | |
| `el` | `else` | |
| `v` | `virtual` | |
| `n` | `namespace` | |
| `u` | `using` | |
| `k` | `const` | |
| `d` | `delete` | |
| `o` | `override` | |
| `r` | `return` | |
| `b` | `break` | |
| `cont` | `continue` | |
| `ke` | `constexpr` | |
| `op` | `operator` | |
| `pub` | `public` | |
| `pri` | `private` | |
| `pro` | `protected` | |
| `which` | `switch` | |

**Untouched:** `void`, `static`, `nullptr`, `if`, `new`, `int`, `bool`, `true`, `false`,
`do`, `template`, `typename`, `concept`, `requires`, `sizeof`, `decltype`,
`noexcept`, `inline`, `extern`, `mutable`, `volatile`, and all other C++ keywords not listed above.

---

## Optional parentheses

`if` and `while` conditions do not require parentheses. Parens are still valid.
The condition is everything between the keyword and the opening `{`.

```
if x > 5 { ... }         →   if (x > 5) { ... }
while running { ... }    →   while (running) { ... }
if (x > 5) { ... }       →   if (x > 5) { ... }   // also valid
```

Single-line bodies:
```
if x > 5 r 0;            →   if (x > 5) return 0;
```

---

## switch → which

`case` keyword is dropped. The value label is used directly.

```
which val
{
    1:
        r 67;
    2:
        b;
}
```
transpiles to:
```cpp
switch (val)
{
    case 1:
        return 67;
    case 2:
        break;
}
```

---

## Elvis operator ??

Truthiness-based (not null-only). Inspired by GCC's `?:` and Kotlin guards.

```
val ?? fallback;        →   { auto _t = val; return _t ? _t : fallback; }
val ?? r;               →   if (!val) return;
val ?? r nullptr;       →   if (!val) return nullptr;
val ?? foo();           →   if (!val) foo();
val ??= fallback;       →   val = val ?? fallback;
```

RHS is a **statement** (return, function call, etc.) → guard form (`if (!val) ...`)
RHS is an **expression** → ternary form

---

## Lambda syntax

No-parameter lambdas capture everything by `&` by default.

```
=> { val = _x + _c; r val }    →   [&](){ val = _x + _c; return val; }
=> x + 1                        →   [&](){ return x + 1; }
[=] => { ... }                  →   [=](){ ... }
```

Rules:
- Standalone `=>` always means lambda
- No parentheses — shrt lambdas take no parameters
- Default capture is `[&]`; prefix with `[=]` or `[varname]` to override

---

## Expression bodies

`=>` after a function signature means implicit return — single expression body.

```
int add(int x, int y) => x + y;       →   int add(int x, int y) { return x + y; }
int value() => _value;                 →   int value() { return _value; }
```

Unified mental model: **`=>` always means "what follows is the result"**
- Standalone = lambda
- After signature = expression body

---

## Implementation notes & known limitations

The transpiler is a token-stream rewriter, not a full expression parser. A few
edge cases follow from that. None affect idiomatic code; each has a simple
work-around (usually: add parentheses).

- **`??` / `??=` left operand is a *postfix* expression.** The left side is taken
  to be an identifier/member-chain optionally ending in a call `(…)` or subscript
  `[…]` — e.g. `find(x) ?? 0`, `arr[i] ?? 0`, `obj.field ?? 0` all work. A *binary*
  left operand is **not** absorbed: `x + a ?? b` becomes `x + (a ?? b)`, not
  `(x + a) ?? b`. Parenthesize when the left side is itself an operator
  expression: write `(x + a) ?? b`.
- **`??` duplicates its left operand** (`(lhs) ? (lhs) : (rhs)`), so a left operand
  with side effects is evaluated twice. Bind it to a name first if that matters.
- **`?.` is field access, pointer-final.** `a?.b?.c` reads fields through pointers;
  it is not meant for method calls (`a?.method()`) or assignment targets.
- **Optional parens are block-form only.** `if cond { … }` works; single-line
  brace-less bodies (`if cond r 0;`) are not rewritten — but the Allman style
  means bodies are always braced anyway.
- **Single-line `which`** expects each label on its own line (labels are detected
  at a line start). Put `case`-labels on their own lines.
- **`$"…"` brace escaping** is not supported; `{` / `}` are always interpolation
  delimiters. Build such strings with plain `std::format` if you need literal
  braces.

A future AST-based front end would remove the first two; the rest are stylistic.
