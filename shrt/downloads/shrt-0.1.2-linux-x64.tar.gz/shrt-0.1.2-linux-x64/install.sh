#!/usr/bin/env sh
set -eu

prefix="${PREFIX:-$HOME/.local}"
bin_dir="$prefix/bin"

mkdir -p "$bin_dir"
install -m 755 "$(dirname "$0")/bin/shrt" "$bin_dir/shrt"

printf 'Installed SHRT to %s/shrt\n' "$bin_dir"
case ":${PATH:-}:" in
  *:"$bin_dir":*) ;;
  *) printf 'Add %s to PATH, then open a new terminal.\n' "$bin_dir" ;;
esac
