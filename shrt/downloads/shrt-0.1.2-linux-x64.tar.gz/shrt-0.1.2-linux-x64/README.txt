SHRT 0.1.2
==========

SHRT is syntax sugar over C++. It transpiles .shrt files to ordinary C++.

Basic usage
-----------

    shrt input.shrt -g -o input.shrt.cpp

Then compile the generated file with a C++20 compiler, for example:

    g++ -std=c++20 input.shrt.cpp -o input

The -g option adds #line directives so compiler diagnostics point back to the
original .shrt source.

Files
-----

    bin/shrt       Linux x64 transpiler
    bin/shrt.exe   Windows x64 transpiler
    install.sh     Linux installer (copies to $PREFIX/bin; default ~/.local)
    install.ps1    Windows installer (copies to LocalAppData and updates user PATH)

Documentation and live playground:

    https://antonveselskyi.com/shrt.html
    https://antonveselskyi.com/shrt-play.html

License: MIT
